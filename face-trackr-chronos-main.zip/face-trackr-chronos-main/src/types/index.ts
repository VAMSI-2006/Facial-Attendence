
export interface Student {
  id: string;
  name: string;
  email: string;
  parentEmail: string;
  image: string;
  attendanceRecords: AttendanceRecord[];
}

export interface AttendanceRecord {
  date: string;
  present: boolean;
}

export interface AttendanceStats {
  totalClasses: number;
  classesAttended: number;
  attendancePercentage: number;
}
