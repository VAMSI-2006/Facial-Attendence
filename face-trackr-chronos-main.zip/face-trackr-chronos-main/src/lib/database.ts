
import { Student, AttendanceRecord, AttendanceStats } from "@/types";

// Initial student data
const initialStudents: Student[] = [
  {
    id: "1",
    name: "Tejas",
    email: "tejas@example.com",
    parentEmail: "tejas.parent@example.com",
    image: "",
    attendanceRecords: []
  },
  {
    id: "2",
    name: "Anish",
    email: "anish@example.com",
    parentEmail: "anish.parent@example.com",
    image: "",
    attendanceRecords: []
  },
  {
    id: "3",
    name: "Karthikeya",
    email: "karthikeya@example.com",
    parentEmail: "karthikeya.parent@example.com",
    image: "",
    attendanceRecords: []
  },
  {
    id: "4",
    name: "Vamsi",
    email: "vamsi@example.com",
    parentEmail: "vamsi.parent@example.com",
    image: "",
    attendanceRecords: []
  }
];

// Check if students exist in localStorage
const getStoredStudents = (): Student[] => {
  const storedStudents = localStorage.getItem("students");
  if (storedStudents) {
    return JSON.parse(storedStudents);
  }
  return initialStudents;
};

// Initialize students
let students = getStoredStudents();

// Save students to localStorage
const saveStudents = () => {
  localStorage.setItem("students", JSON.stringify(students));
};

export const getAllStudents = (): Student[] => {
  return [...students];
};

export const getStudentById = (id: string): Student | undefined => {
  return students.find(student => student.id === id);
};

export const updateStudentImage = (id: string, imageUrl: string): void => {
  students = students.map(student => 
    student.id === id ? { ...student, image: imageUrl } : student
  );
  saveStudents();
};

export const markAttendance = (studentIds: string[], date: string): void => {
  students = students.map(student => {
    const isPresent = studentIds.includes(student.id);
    
    // Check if attendance for this date already exists
    const existingRecordIndex = student.attendanceRecords.findIndex(
      record => record.date === date
    );
    
    let updatedRecords = [...student.attendanceRecords];
    
    if (existingRecordIndex >= 0) {
      // Update existing record
      updatedRecords[existingRecordIndex] = { date, present: isPresent };
    } else {
      // Add new record
      updatedRecords.push({ date, present: isPresent });
    }
    
    return {
      ...student,
      attendanceRecords: updatedRecords
    };
  });
  
  saveStudents();
};

export const getAttendanceStats = (studentId: string): AttendanceStats => {
  const student = getStudentById(studentId);
  
  if (!student) {
    return { totalClasses: 0, classesAttended: 0, attendancePercentage: 0 };
  }
  
  const totalClasses = student.attendanceRecords.length;
  const classesAttended = student.attendanceRecords.filter(record => record.present).length;
  const attendancePercentage = totalClasses === 0 
    ? 0 
    : (classesAttended / totalClasses) * 100;
    
  return {
    totalClasses,
    classesAttended,
    attendancePercentage: Math.round(attendancePercentage * 10) / 10 // Round to 1 decimal place
  };
};

export const resetAttendance = (): void => {
  students = students.map(student => ({
    ...student,
    attendanceRecords: []
  }));
  saveStudents();
};
