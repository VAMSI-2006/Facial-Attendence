
import * as faceapi from 'face-api.js';
import { toast } from '@/components/ui/use-toast';
import { Student } from '@/types';

// Load all required models
const loadModels = async () => {
  try {
    await faceapi.nets.ssdMobilenetv1.loadFromUri('/models');
    await faceapi.nets.faceLandmark68Net.loadFromUri('/models');
    await faceapi.nets.faceRecognitionNet.loadFromUri('/models');
    return true;
  } catch (error) {
    console.error('Error loading face-api models:', error);
    toast({
      title: 'Error',
      description: 'Failed to load facial recognition models. Please try again.',
      variant: 'destructive'
    });
    return false;
  }
};

// Extract face descriptors from a student image
export const getFaceDescriptor = async (image: HTMLImageElement): Promise<Float32Array | null> => {
  const modelsLoaded = await loadModels();
  if (!modelsLoaded) return null;

  try {
    const detections = await faceapi.detectSingleFace(image)
      .withFaceLandmarks()
      .withFaceDescriptor();
    
    if (!detections) {
      toast({
        title: 'No Face Detected',
        description: 'We could not detect a face in this image. Please try with a clearer photo.',
        variant: 'destructive'
      });
      return null;
    }
    
    return detections.descriptor;
  } catch (error) {
    console.error('Error getting face descriptor:', error);
    toast({
      title: 'Error',
      description: 'Failed to process the face in this image.',
      variant: 'destructive'
    });
    return null;
  }
};

// Compare faces and return matching student IDs
export const recognizeFaces = async (
  groupPhoto: HTMLImageElement, 
  students: Student[]
): Promise<string[]> => {
  const modelsLoaded = await loadModels();
  if (!modelsLoaded) return [];

  const studentsWithImages = students.filter(student => student.image);
  
  if (studentsWithImages.length === 0) {
    toast({
      title: 'No Reference Images',
      description: 'No student images have been uploaded for comparison.',
      variant: 'destructive'
    });
    return [];
  }

  try {
    console.log("Starting face recognition on group photo...");
    
    // Detect all faces in group photo
    const detections = await faceapi.detectAllFaces(groupPhoto)
      .withFaceLandmarks()
      .withFaceDescriptors();
    
    console.log(`Detected ${detections.length} faces in group photo`);
    
    if (detections.length === 0) {
      toast({
        title: 'No Faces Detected',
        description: 'We could not detect any faces in the group photo.',
        variant: 'destructive'
      });
      return [];
    }
    
    // Create labeled face descriptors for each student
    const labeledDescriptorsPromises = studentsWithImages.map(async (student) => {
      try {
        const img = await createImageElement(student.image);
        const descriptor = await getFaceDescriptor(img);
        
        if (!descriptor) {
          console.log(`No descriptor found for student: ${student.name}`);
          return null;
        }
        
        console.log(`Created descriptor for student: ${student.name}`);
        return new faceapi.LabeledFaceDescriptors(
          student.id,
          [descriptor]
        );
      } catch (error) {
        console.error(`Error processing student ${student.name}:`, error);
        return null;
      }
    });
    
    const labeledDescriptors = await Promise.all(labeledDescriptorsPromises);
    
    // Filter out nulls
    const validLabeledDescriptors = labeledDescriptors.filter(Boolean) as faceapi.LabeledFaceDescriptors[];
    console.log(`Created ${validLabeledDescriptors.length} valid descriptors for matching`);
    
    if (validLabeledDescriptors.length === 0) {
      toast({
        title: 'Processing Error',
        description: 'Could not create valid face descriptors for students.',
        variant: 'destructive'
      });
      return [];
    }
    
    // Create face matcher with lower distance threshold for better matching
    const faceMatcher = new faceapi.FaceMatcher(validLabeledDescriptors, 0.6);
    
    // Find matches for each face in group photo
    const matches = detections.map(detection => {
      const match = faceMatcher.findBestMatch(detection.descriptor);
      console.log(`Match result: ${match.toString()}`);
      return match;
    });
    
    // Extract student IDs from matches (excluding 'unknown' matches)
    const matchedStudentIds = matches
      .filter(match => match.label !== 'unknown')
      .map(match => match.label);
    
    console.log(`Matched student IDs: ${matchedStudentIds.join(', ')}`);
    
    // If we found matches but they're all unknown, show a toast
    if (matches.length > 0 && matchedStudentIds.length === 0) {
      toast({
        title: 'No Students Recognized',
        description: 'We detected faces, but couldn\'t match them with any students.',
        variant: 'destructive'
      });
    }
    
    return matchedStudentIds;
  } catch (error) {
    console.error('Error in face recognition:', error);
    toast({
      title: 'Recognition Error',
      description: 'An error occurred during face recognition.',
      variant: 'destructive'
    });
    return [];
  }
};

// Helper to create an HTMLImageElement from a data URL
const createImageElement = (dataUrl: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
  });
};
