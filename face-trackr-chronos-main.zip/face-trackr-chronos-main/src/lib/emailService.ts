
import { Student } from "@/types";
import { toast } from "@/components/ui/use-toast";

export const sendAttendanceAlert = async (student: Student, attendancePercentage: number): Promise<boolean> => {
  // In a real app, this would connect to an email API like SendGrid, Mailgun, etc.
  // For this demo, we'll simulate sending an email
  
  console.log(`Sending email to ${student.parentEmail} about ${student.name}'s attendance (${attendancePercentage}%)`);
  
  // Simulate an API call
  try {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // For demo purposes, show a toast
    toast({
      title: "Email Notification Sent",
      description: `Alert sent to ${student.parentEmail} about ${student.name}'s attendance (${attendancePercentage}%)`,
    });
    
    return true;
  } catch (error) {
    console.error("Error sending email:", error);
    
    toast({
      title: "Email Sending Failed",
      description: "Could not send the attendance notification email.",
      variant: "destructive"
    });
    
    return false;
  }
};

export const checkAndSendAttendanceAlerts = async (students: Student[]): Promise<void> => {
  const THRESHOLD_PERCENTAGE = 75;
  
  for (const student of students) {
    if (student.attendanceRecords.length === 0) continue;
    
    const totalClasses = student.attendanceRecords.length;
    const classesAttended = student.attendanceRecords.filter(record => record.present).length;
    const attendancePercentage = (classesAttended / totalClasses) * 100;
    
    if (attendancePercentage < THRESHOLD_PERCENTAGE) {
      await sendAttendanceAlert(student, attendancePercentage);
    }
  }
};
