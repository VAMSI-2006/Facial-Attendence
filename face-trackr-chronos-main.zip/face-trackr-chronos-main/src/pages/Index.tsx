
import { useEffect } from "react";
import AppLayout from "@/components/AppLayout";
import AttendanceDashboard from "@/components/AttendanceDashboard";
import { toast } from "@/components/ui/use-toast";
import { AlertCircle } from "lucide-react";

const Index = () => {
  useEffect(() => {
    // Check if the face-api models directory exists (this would be setup in a real app)
    toast({
      title: "Demo Mode",
      description: (
        <div className="flex items-start space-x-2">
          <AlertCircle className="h-5 w-5 text-orange-500 mt-0.5" />
          <div>
            <p>This is a demo version with simulated face recognition.</p>
            <p className="text-xs mt-1">In a production app, you would need to download and set up face-api.js models.</p>
          </div>
        </div>
      ),
      duration: 8000,
    });
  }, []);

  return (
    <AppLayout>
      <AttendanceDashboard />
    </AppLayout>
  );
};

export default Index;
