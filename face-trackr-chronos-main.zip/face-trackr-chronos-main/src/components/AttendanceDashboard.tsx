
import { useState, useEffect } from "react";
import { Student } from "@/types";
import { getAllStudents, markAttendance } from "@/lib/database";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { recognizeFaces } from "@/lib/faceRecognition";
import { checkAndSendAttendanceAlerts } from "@/lib/emailService";
import ImageUpload from "./ImageUpload";
import StudentCard from "./StudentCard";
import { useToast } from "@/components/ui/use-toast";
import { CalendarIcon, CheckCircle2, MailWarning, XCircle, Loader2 } from "lucide-react";

const AttendanceDashboard = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [groupPhoto, setGroupPhoto] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [recognizedStudents, setRecognizedStudents] = useState<string[]>([]);
  const [dateString, setDateString] = useState<string>("");
  const { toast } = useToast();

  // Load students on component mount
  useEffect(() => {
    const fetchStudents = () => {
      const data = getAllStudents();
      setStudents(data);
    };

    fetchStudents();
    // Set today's date as default
    setDateString(new Date().toISOString().split('T')[0]);
  }, []);

  // Handle group photo upload
  const handleGroupPhotoUpload = (imageData: string) => {
    setGroupPhoto(imageData);
    // Clear previous recognition results
    setRecognizedStudents([]);
  };

  // Process attendance from group photo
  const processAttendance = async () => {
    if (!groupPhoto) {
      toast({
        title: "Missing Information",
        description: "Please upload a group photo to take attendance.",
        variant: "destructive",
      });
      return;
    }

    if (!dateString) {
      toast({
        title: "Missing Information",
        description: "Please select a date for this attendance record.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      toast({
        title: "Processing",
        description: "Analyzing faces in the group photo...",
      });
      
      // Create an image element from the data URL
      const img = document.createElement('img');
      img.src = groupPhoto;
      
      // Wait for the image to load
      await new Promise((resolve) => {
        img.onload = resolve;
      });
      
      // Run face recognition
      const recognizedIds = await recognizeFaces(img, students);
      
      if (recognizedIds.length === 0) {
        toast({
          title: "No Students Recognized",
          description: "We couldn't recognize any students in this photo.",
          variant: "destructive",
        });
        setIsProcessing(false);
        return;
      }
      
      setRecognizedStudents(recognizedIds);
      
      // Show recognition results
      const recognizedCount = recognizedIds.length;
      const recognizedNames = students
        .filter(student => recognizedIds.includes(student.id))
        .map(student => student.name)
        .join(", ");
        
      toast({
        title: "Recognition Complete",
        description: `Recognized ${recognizedCount} students: ${recognizedNames}`,
      });
    } catch (error) {
      console.error("Recognition error:", error);
      toast({
        title: "Processing Error",
        description: "An error occurred while processing the image.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Save attendance records and check for low attendance
  const saveAttendance = async () => {
    if (recognizedStudents.length === 0) {
      toast({
        title: "No Data to Save",
        description: "Please process a group photo first.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Mark attendance in database
      markAttendance(recognizedStudents, dateString);
      
      // Refresh student data
      const updatedStudents = getAllStudents();
      setStudents(updatedStudents);
      
      // Check for attendance below threshold and send emails
      await checkAndSendAttendanceAlerts(updatedStudents);
      
      toast({
        title: "Attendance Saved",
        description: "Attendance records have been updated successfully.",
      });
      
      // Clear group photo and recognition data
      setGroupPhoto("");
      setRecognizedStudents([]);
    } catch (error) {
      console.error("Error saving attendance:", error);
      toast({
        title: "Save Error",
        description: "An error occurred while saving attendance records.",
        variant: "destructive",
      });
    }
  };

  // Handle date change
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDateString(e.target.value);
  };

  // Refresh student data
  const refreshStudents = () => {
    const data = getAllStudents();
    setStudents(data);
  };

  // Count students with photos
  const studentsWithPhotos = students.filter(student => student.image).length;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Student Management */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-education-800">Student Management</h2>
          </div>

          {/* Student Configuration Progress */}
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Student Photo Setup Progress</span>
                  <span className="text-sm font-medium">{studentsWithPhotos}/{students.length}</span>
                </div>
                <Progress value={(studentsWithPhotos / students.length) * 100} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Student Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {students.map((student) => (
              <StudentCard 
                key={student.id} 
                student={student} 
                onUpdate={refreshStudents} 
              />
            ))}
          </div>
        </div>

        {/* Right Column: Attendance Taking */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-education-800">Take Attendance</h2>
          
          <Card>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-2">
                <label htmlFor="attendance-date" className="text-sm font-medium flex items-center">
                  <CalendarIcon className="h-4 w-4 mr-2 text-education-600" />
                  Attendance Date
                </label>
                <input
                  id="attendance-date"
                  type="date"
                  value={dateString}
                  onChange={handleDateChange}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-education-500"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Group Photo</label>
                <ImageUpload onImageCapture={handleGroupPhotoUpload} currentImage={groupPhoto} />
              </div>
              
              <div className="flex space-x-2">
                <Button
                  onClick={processAttendance}
                  disabled={!groupPhoto || isProcessing}
                  className="w-full bg-education-600 hover:bg-education-700"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    "Process Attendance"
                  )}
                </Button>
              </div>
              
              {recognizedStudents.length > 0 && (
                <div className="mt-4 p-4 border rounded-md bg-gray-50">
                  <h3 className="text-sm font-medium flex items-center mb-2">
                    <CheckCircle2 className="h-4 w-4 mr-2 text-green-600" />
                    Recognized Students ({recognizedStudents.length})
                  </h3>
                  <div className="space-y-1">
                    {students
                      .filter(student => recognizedStudents.includes(student.id))
                      .map(student => (
                        <div key={student.id} className="flex items-center">
                          <div className="h-6 w-6 rounded-full bg-green-100 flex items-center justify-center mr-2">
                            <CheckCircle2 className="h-3 w-3 text-green-600" />
                          </div>
                          <span>{student.name}</span>
                        </div>
                      ))}
                  </div>
                  
                  {students.length > recognizedStudents.length && (
                    <>
                      <h3 className="text-sm font-medium flex items-center mb-2 mt-4">
                        <XCircle className="h-4 w-4 mr-2 text-red-600" />
                        Absent Students ({students.length - recognizedStudents.length})
                      </h3>
                      <div className="space-y-1">
                        {students
                          .filter(student => !recognizedStudents.includes(student.id))
                          .map(student => (
                            <div key={student.id} className="flex items-center">
                              <div className="h-6 w-6 rounded-full bg-red-100 flex items-center justify-center mr-2">
                                <XCircle className="h-3 w-3 text-red-600" />
                              </div>
                              <span>{student.name}</span>
                            </div>
                          ))}
                      </div>
                    </>
                  )}
                  
                  <Button
                    onClick={saveAttendance}
                    className="w-full mt-4 bg-education-600 hover:bg-education-700"
                  >
                    Save Attendance Records
                  </Button>
                  
                  <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded text-xs text-yellow-800">
                    <div className="flex items-start">
                      <MailWarning className="h-4 w-4 mr-2 flex-shrink-0" />
                      <p>Attendance below 75% will trigger an automatic email notification to parents.</p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AttendanceDashboard;
