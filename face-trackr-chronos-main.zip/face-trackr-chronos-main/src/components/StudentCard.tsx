
import { useState } from "react";
import { Student, AttendanceStats } from "@/types";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getAttendanceStats, updateStudentImage } from "@/lib/database";
import ImageUpload from "./ImageUpload";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Edit, User, Check, XCircle } from "lucide-react";

interface StudentCardProps {
  student: Student;
  onUpdate: () => void;
}

const StudentCard: React.FC<StudentCardProps> = ({ student, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const stats = getAttendanceStats(student.id);

  const handleImageCapture = (imageData: string) => {
    updateStudentImage(student.id, imageData);
    onUpdate();
    setIsEditing(false);
  };

  const getAttendanceStatusColor = (percentage: number) => {
    if (percentage >= 90) return "bg-green-100 text-green-800 border-green-300";
    if (percentage >= 75) return "bg-yellow-100 text-yellow-800 border-yellow-300";
    return "bg-red-100 text-red-800 border-red-300";
  };

  return (
    <Card className="overflow-hidden transition-shadow duration-300 hover:shadow-lg">
      <CardHeader className="bg-education-50 pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-semibold">{student.name}</CardTitle>
          <Button
            variant="ghost" 
            size="icon" 
            onClick={() => setIsEditing(prev => !prev)}
          >
            <Edit className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        {isEditing ? (
          <ImageUpload 
            onImageCapture={handleImageCapture} 
            currentImage={student.image}
          />
        ) : (
          <div className="mb-4 flex justify-center">
            {student.image ? (
              <Avatar className="h-20 w-20">
                <AvatarImage src={student.image} alt={student.name} />
                <AvatarFallback className="bg-education-100 text-education-800">
                  <User className="h-8 w-8" />
                </AvatarFallback>
              </Avatar>
            ) : (
              <div className="h-20 w-20 rounded-full bg-education-100 flex items-center justify-center">
                <User className="h-8 w-8 text-education-800" />
              </div>
            )}
          </div>
        )}

        <div className="mt-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Email:</span>
            <span className="font-medium">{student.email}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Parent:</span>
            <span className="font-medium">{student.parentEmail}</span>
          </div>

          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="w-full mt-2">
                View Attendance
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{student.name}'s Attendance</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-3 bg-education-50 rounded-md">
                    <p className="text-sm text-gray-500">Total Classes</p>
                    <p className="text-xl font-bold">{stats.totalClasses}</p>
                  </div>
                  <div className="p-3 bg-education-50 rounded-md">
                    <p className="text-sm text-gray-500">Present</p>
                    <p className="text-xl font-bold">{stats.classesAttended}</p>
                  </div>
                  <div className={`p-3 rounded-md ${getAttendanceStatusColor(stats.attendancePercentage)}`}>
                    <p className="text-sm">Percentage</p>
                    <p className="text-xl font-bold">{stats.attendancePercentage}%</p>
                  </div>
                </div>

                <div className="mt-4">
                  <h4 className="font-medium mb-2">Attendance History</h4>
                  <div className="max-h-60 overflow-y-auto space-y-1">
                    {student.attendanceRecords.length > 0 ? (
                      student.attendanceRecords
                        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                        .map((record, index) => (
                          <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                            <span>{new Date(record.date).toLocaleDateString()}</span>
                            {record.present ? (
                              <Badge className="bg-green-100 text-green-800 border-green-300">
                                <Check className="h-3 w-3 mr-1" /> Present
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-red-50 text-red-800 border-red-300">
                                <XCircle className="h-3 w-3 mr-1" /> Absent
                              </Badge>
                            )}
                          </div>
                        ))
                    ) : (
                      <p className="text-gray-500 text-center py-4">No attendance records</p>
                    )}
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
      <CardFooter className="bg-gray-50 px-4 py-3">
        <div className="w-full flex justify-between items-center">
          <span className="text-sm text-gray-500">Attendance:</span>
          <Badge className={`${getAttendanceStatusColor(stats.attendancePercentage)}`}>
            {stats.attendancePercentage}%
          </Badge>
        </div>
      </CardFooter>
    </Card>
  );
};

export default StudentCard;
