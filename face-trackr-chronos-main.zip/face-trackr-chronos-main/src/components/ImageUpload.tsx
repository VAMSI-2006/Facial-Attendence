
import React, { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { Camera, Upload, X } from "lucide-react";

interface ImageUploadProps {
  onImageCapture: (imageData: string) => void;
  currentImage?: string;
}

const ImageUpload: React.FC<ImageUploadProps> = ({ onImageCapture, currentImage }) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentImage || null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isCapturingWebcam, setIsCapturingWebcam] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  let streamRef = useRef<MediaStream | null>(null);

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setPreviewUrl(result);
      onImageCapture(result);
    };
    reader.readAsDataURL(file);
  };

  // Start webcam capture
  const startWebcam = async () => {
    setIsCapturingWebcam(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
      }
    } catch (err) {
      console.error("Error accessing webcam:", err);
      toast({
        title: "Webcam Error",
        description: "Could not access your camera. Please check permissions.",
        variant: "destructive",
      });
      setIsCapturingWebcam(false);
    }
  };

  // Capture image from webcam
  const captureImage = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    if (video && canvas) {
      const context = canvas.getContext("2d");
      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const imageData = canvas.toDataURL("image/png");
        setPreviewUrl(imageData);
        onImageCapture(imageData);
        
        stopWebcam();
      }
    }
  };

  // Stop webcam stream
  const stopWebcam = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    setIsCapturingWebcam(false);
  };

  // Clear selected image
  const clearImage = () => {
    setPreviewUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    onImageCapture("");
  };

  return (
    <div className="mb-6">
      {/* Hidden canvas for image capture */}
      <canvas ref={canvasRef} className="hidden"></canvas>
      
      {/* Image preview */}
      {previewUrl && !isCapturingWebcam && (
        <div className="mb-4 relative">
          <img 
            src={previewUrl} 
            alt="Preview" 
            className="w-full max-h-64 object-contain border rounded-md" 
          />
          <Button 
            variant="outline" 
            size="icon" 
            className="absolute top-2 right-2 bg-white rounded-full"
            onClick={clearImage}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}
      
      {/* Webcam preview */}
      {isCapturingWebcam && (
        <div className="mb-4 relative">
          <video 
            ref={videoRef} 
            autoPlay 
            className="w-full max-h-64 object-contain border rounded-md"
          />
          <div className="mt-2 flex justify-center">
            <Button onClick={captureImage} className="mr-2">
              Take Photo
            </Button>
            <Button variant="outline" onClick={stopWebcam}>
              Cancel
            </Button>
          </div>
        </div>
      )}
      
      {/* Upload controls */}
      {!isCapturingWebcam && !previewUrl && (
        <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center">
          <div className="flex flex-col items-center justify-center space-y-2">
            <div className="text-gray-500">
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <p className="mt-2">Upload or capture a photo</p>
            </div>
            <div className="flex space-x-2">
              <div>
                <Input
                  id="image-upload"
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  className="hidden"
                />
                <Button 
                  variant="outline" 
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Upload
                </Button>
              </div>
              <Button 
                variant="outline" 
                onClick={startWebcam}
              >
                <Camera className="mr-2 h-4 w-4" />
                Camera
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageUpload;
